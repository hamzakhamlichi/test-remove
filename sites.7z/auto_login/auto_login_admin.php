<html>
<head>
<style>
div.container{
	width: 950px;
}
div.autologin_style{
	padding: 5px;
	background: #EBEBEB;
	margin: 10px;
	width:450px;
	height:345px;
	font-family: Calibri,Helvetica,Arial,sans-serif;
	float: left; 
}
div.autologin_style_test{
	padding: 5px;
	margin: 0px 10px 10px 10px;
	background: #EBEBEB;
	width: 450px;
	height: 280px;
	font-family: Calibri,Helvetica,Arial,sans-serif;
	float: left;
}
div.information_pane{
	height:280px;
	width: 450px;
	padding: 5px;
	background: #EBEBEB;
	margin: 0px 10px 10px 0;
	font-family: Calibri,Helvetica,Arial,sans-serif;
	float:left;
}
div.advanced{
	padding: 5px;
	background: #EBEBEB;
	margin: 10px 10px 10px 0px;
	width:450px;
	height:345px;
	font-family: Calibri,Helvetica,Arial,sans-serif;
	float: left; 
}
div.banner{
	padding 5px;
	margin-left: 10px;
	margin-top: 15px;
	font-family: Calibri,Helvetica,Arial,sans-serif;
}
h1{
	margin: 0;
}
h2{
	margin: 0;
}
h3{
	margin: 0;
}
h4{
	margin: 0;
}
</style>
</head>
<?php 
//Debug
$debug = "false";

//Where are we?
$this_page = $_SERVER['PHP_SELF'].'?page='.$_GET['page'];

//If this is a test, we will use this variable
$bool_test = 0;
$test_user = '';
//If admin options updated (uses hidden field)
if ($_POST['stage'] == 'process') {
    update_option('autologin_account_suffix', $_POST['account_suffix']);
	update_option('autologin_base_dn', $_POST['base_dn']);
	update_option('autologin_domain_controllers', $_POST['domain_controller']);

	//Version 1.3
	update_option('autologin_directory_type',$_POST['LDAP']);
	update_option('autologin_login_mode',$_POST['mode']);
	update_option('autologin_group',$_POST['group_name']);
	update_option('autologin_account_type',$_POST['create_type']);
	
	//Version 1.3.0.2
	update_option('autologin_security_mode',$_POST['security_mode']);
}
//Test credentials
elseif ($_POST['stage'] == 'test') 
{
	global $bool_test;
	global $test_user;
	$test_user = getLDAPUserInfo($_POST['test_username']);
	
	if ($test_user)
	{
		$bool_test = 1;
	}
	else 
	{
		$bool_test = 2;
	}
}
//Load settings, etc
$autologin_account_suffix = get_option("autologin_account_suffix");
$autologin_base_dn = get_option("autologin_base_dn");
$autologin_domain_controllers = get_option("autologin_domain_controllers");

?>
<body>
<div class="container">
<div class="banner"><h1>Afnor Auto Login 0.0.2</h1></div>
<form style="display::inline;" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>&updated=true">
<div class="autologin_style">
<h2>Settings</h2>
<h3>These are rather important.</h3>
<p><strong>Account Suffix:</strong><br />
<input name="account_suffix" type="text" value="<?php  echo $autologin_account_suffix; ?>" size="35" /><br />
*Probably the suffix of your e-mail addresses. Example: @domain.com
 </p><p><strong>Base DN:</strong><br />
<input name="base_dn" type="text" value="<?php  echo $autologin_base_dn; ?>" size="35" /><br />
*Example: For subdomain.domain.sufix use DC=subdomain,DC=domain,DC=suffix 
  </p>
 <p><strong>Domain Controller(s):</strong><br />
<input name="domain_controller" type="text" value="<?php  echo $autologin_domain_controllers; ?>" size="60" /><br />
*Separate with semi-colons.
  </p>
<input type="hidden" name="stage" value="process" />
<input type="submit" name="button_submit" value="<?php _e('Update Options', 'auto-login') ?> &raquo;" />
</div>
</form>
<div class="autologin_style_test">
<h2>Test Settings</h2>
<h3>Use this form to test those settings you saved.* This <em>will</em> test user creation and group membership.</h3>
<h4>*You did save them, right?</h4>
<form method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
  <p>Username:<br />
<input name="test_username" type="text" size="35" />
<!--
 </p><p>Password:<br />
<input name="test_password" type="password" size="35" />
  </p>
 -->
<input type="hidden" name="stage" value="test" />
<input type="submit" name="button_submit" value="<?php _e('Test Settings', 'auto-login') ?> &raquo;" />
</form>
<p>
<h4>Test Results:</h4>
<?php
if($bool_test == 0)
{
	echo "Nothing to report yet, Mr. Fahrenheit.";
}
if($bool_test == 1)
{
	echo "Congratulations! The test succeeded. This account is able to login.";
	print_r($test_user);
}
elseif($bool_test == 2)
{
	echo "Failure. Your settings do not seem to work yet or the credentials are either wrong or have insufficient group membership.";
}
?>
</p>
</div>
</div>
</body>
</html>