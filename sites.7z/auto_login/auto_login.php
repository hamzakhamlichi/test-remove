<?php
/*
Plugin Name: Auto Login
Plugin URI: http://fxnion.free.fr/
Description: Auto Log les utilisatereurs AFNOR
Author: Fx NION
Author URI: http://fxnion.free.fr/
Version: 0.0.3
*/
require_once(ABSPATH.WPINC.'/registration.php');

/**
 * Include admin script.
 */
function autologin_menu ()
{
	include(dirname(__FILE__).'/auto_login_admin.php');
}

/**
 * Add a menu item into admin.
 */
function autologin_admin_actions ()
{
	add_options_page(
		'Afnor Auto Login',
		'Afnor Auto Login',
		10,
		'auto_login',
		'autologin_menu'
	);
}

/**
 * Hook to store default admin settings.
 */
function autologin_activation_hook ()
{
	add_option('autologin_account_suffix', '@mydomain.local');
	add_option('autologin_base_dn', 'dc=mydomain,dc=local');
	add_option('autologin_domain_controllers', 'dc01.mydomain.local');
}

//Add the menu
add_action('admin_menu', 'autologin_admin_actions');

/**
 * Retrieve LDAP user info.
 * @param $user User identifier
 * @param $attr Search attribute
 * @return array|false
 */
function getLDAPUserInfo ( $user, $attr = 'uid' )
{	
	$LDAPServerPort = 389;
	$LDAPServerName = get_option("autologin_domain_controllers");
	$LDAPBaseDN = get_option("autologin_base_dn");
	
	ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
	$ds=ldap_connect($LDAPServerName, $LDAPServerPort);

	if ($ds)
	{
		$r=ldap_bind($ds);
		$sr=ldap_search($ds, $LDAPBaseDN, "$attr=$user");
		$info = ldap_get_entries($ds, $sr);
		@ldap_close($ds);

		if (!$info)
		{
			return false;
		}

		$info = $info[0];
		$ldap_user_info = array(
			'acronyme' => $user,
			'name' => $info['cn'][0],
			'firstname' => $info['sn'][0],
			'matricule' => $info['employeenumber'][0],
			'type_emp' => $info['employeetype'][0],
			'direction' => $info['afnoruserbizdepartment'][0],
			'departement' => $info['ou'][0],
			'localisation' => $info['st'][0],
			'telephone' => $info['telephonenumber'][0],
			'numero_interne' => $info['pager'][0],
			'email' => $info['mail'][0],
			'role' => $info['afnoruserbizrole'][0]
		);
		return $ldap_user_info;
	}
	return false;
}

/**
 * Main authentication function.
 */
function auto_login ()
{
	global $_SERVER, $wpdb;

	// If user is already connected, do nothing.
	if (is_user_logged_in())
	{
		return;
	}

	// Prepare values which will store information.
	$username = null;
	$usermail = null;
	$sso_auth_header_username = 'Auth-User';
	$sso_auth_header_mail = 'Auth-Mail';
	$sso_encoding = 'clear'; // ou 'base64';

	// Retrieve informations from HTTP headers.
	$headers = apache_request_headers();
	if (isset($headers) && isset($headers[$sso_auth_header_username]))
	{
		$username = trim(strtolower($headers[$sso_auth_header_username]));
	}
	if (isset($headers) && isset($headers[$sso_auth_header_mail]))
	{
		$usermail = trim(strtolower($headers[$sso_auth_header_mail]));
	}

	// If no information found into headers, try to get it from HTTP environment.
	if (is_null($username))
	{
		$cred = explode('\\', $_SERVER['REMOTE_USER']);
		if (count($cred) == 1)
		{
			array_unshift($cred, '(no domain info - perhaps SSPIOmitDomain is On)');
		}
		$domain = null;
		list($domain, $username) = $cred;
		$username = strtolower($username);
	}

	// Try to retrieve user from its login.
	// If no user, try to found it by mail address. If it works, user login has changed,
	// and we should migrate it.
	$user = get_userdatabylogin($username);
	if (!$user && !is_null($usermail))
	{
		$user = get_user_by_email($usermail);
	}

	// Now try to retrieve user information from LDAP directory.
	$ldap_user_info = getLDAPUserInfo($username);
	if (!is_array($ldap_user_info))
	{
		return;
	}

	// User is not found, then auto-create it!
	if (!$user)
	{
		$userData = array(
			'user_pass'     => microtime(),
			'user_login'    => $username,
			'user_nicename' => sanitize_title($ldap_user_info['firstname'].'-'.$ldap_user_info['name']),
			'user_email'    => strtolower($ldap_user_info['email']),
			'display_name'  => ucwords(strtolower($ldap_user_info['firstname'].' '.$ldap_user_info['name'])),
			'first_name'    => ucwords(strtolower($ldap_user_info['firstname'])),
			'last_name'     => ucwords(strtolower($ldap_user_info['name'])),
			'aim'           => $ldap_user_info['direction'].'/'.$ldap_user_info['departement']
			//'role'        => strtolower(get_option('autologin_account_type'))
		);
		wp_insert_user($userData);
	}

	// Always do some updates if user is found.
	else
	{
		// Update login in database if it has changed!
		// This is done before all other updates, because user_nicename is changed
		// by wp_udpate_user if login is different.
		// To update all things, entries are removed from Wordpress caches.
		if (strtolower($user->user_login) != $username)
		{
			$wpdb->update(
				$wpdb->users,
				array('user_login' => $username),
				array('ID' => $user->ID)
			);
			wp_cache_delete(strtolower($user->user_login), 'userlogins');
			wp_cache_delete($username, 'userlogins');
		}
		// To be sure that user_nicename will not change, we have to set user_login.
		$userData = array(
			'ID' => $user->ID,
			'user_login' => $username,
			'aim' => $ldap_user_info['direction'].'/'.$ldap_user_info['departement']
		);
		wp_update_user($userData);
	}

	// Login user.
	$user = get_userdatabylogin($username);
	wp_set_current_user($user->ID, $username);
	wp_set_auth_cookie($user->ID);
	do_action('wp_login', $username);
}

/**
 * Add auto_login action into wordpress authentication workflow.
 */
add_action('init', 'auto_login');

?>
