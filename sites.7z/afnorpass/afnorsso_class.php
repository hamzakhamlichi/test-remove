<?php
class AfnorSSO
{

    const AF_NEWUSERROLE = 'subscriber';
    const COMPTEWEB_ACCOUNT_WSDL_URL = '/Services/ServiceAccount.svc?singleWsdl';
    const COMPTEWEB_AUTHENTICATION_WSDL_URL = '/Services/ServiceAuthentication.svc?singlewsdl';
    const COMPTEWEB_ACCOUNT_CREATION_WSDL_URL = '/Services/ServiceAccount.svc?singlewsdl';

    const COMPTEWEB_AUTHENTICATION_SSO = 'CheckSSO';
    const COMPTEWEB_AUTHENTICATION_SSO_RESULT = 'CheckSSOResult';

    const COMPTEWEB_AUTHENTICATION_AUTHENTICATE = 'Authenticate';
    const COMPTEWEB_AUTHENTICATION_AUTHENTICATE_RESULT = 'AuthenticateResult';

    const COMPTEWEB_IS_ACCOUNT_EXIST = 'IsAccountExists';
    const COMPTEWEB_IS_ACCOUNT_EXIST_RESULT = 'IsAccountExistsResult';

    const COMPTEWEB_COOKIE_NAME = 'lemonldap_afnor';
    const COMPTEWEB_DOMAINE_NAME = '.afnor.org';
   
    const COMPTEWEB_FORCE_LOGOUT = 0;

    const COMPTEWEB_ACCOUNT_INFOS = 'GetAccount';
    const COMPTEWEB_ACCOUNT_INFOS_RESULT = 'GetAccountResult';
    const COMPTEWEB_ACCOUNT_INFOS_FULL = 'GetAccountFull';
    const COMPTEWEB_ACCOUNT_INFOS_FULL_RESULT = 'GetAccountFullResult';

    const COMPTEWEB_ACCOUNT_CREATION = 'CreateAccountInactive';
    const COMPTEWEB_ACCOUNT_CREATION_RESILT = 'CreateAccountInactiveResult';
	
	const COMPTEWEB_CONSENTEMENT_GET = 'GetEntiteConsentement';
	const COMPTEWEB_CONSENTEMENT_GET_RESULT = 'GetEntiteConsentementResult';
	const COMPTEWEB_CONSENTEMENT_UPDATE = 'UpdateConsentement';
	const COMPTEWEB_CONSENTEMENT_UPDATE_RESULT = 'UpdateConsentementResult';

    static function isAccountExists($host, $mail){
        try{
            $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_CREATION_WSDL_URL );
            $params = array( "parameters" => array('email' => $mail));

            $cwresult = $soap->__soapCall(self::COMPTEWEB_IS_ACCOUNT_EXIST,$params);
            $resultName = self::COMPTEWEB_IS_ACCOUNT_EXIST_RESULT;
            return $cwresult->$resultName;

        } catch (SoapFault $fault) {
			die('fault');
            return false;
        }
    }

    static function createAccount($host , $afnorpass_info){
        try{
            $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_CREATION_WSDL_URL );
            $params = array( "parameters" => array('request' => (object) $afnorpass_info));

            $cwresult = $soap->__soapCall(self::COMPTEWEB_ACCOUNT_CREATION,$params);
            $resultName = self::COMPTEWEB_ACCOUNT_CREATION_RESILT;
            return array(true,$cwresult->$resultName);

        } catch (SoapFault $fault) {
            $res = array(false,$fault->getMessage());
            return $res;
        }
    }
    static function checkSSO($host,$cookie_name)
    {
        try{
            $soapAuth = new SoapClient($host . self::COMPTEWEB_AUTHENTICATION_WSDL_URL );
            $params = array( "parameters" => array('request' => (object) array("Value" => $_COOKIE[$cookie_name])));
            $cwresult = $soapAuth->__soapCall(self::COMPTEWEB_AUTHENTICATION_SSO, $params);
            $resultName = self::COMPTEWEB_AUTHENTICATION_SSO_RESULT;
            $login = $cwresult->$resultName;
        } catch (SoapFault $fault) {
            //$errors = $fault->getMessage()."\n".$fault->getTraceAsString();
            return false;
        }

        if (filter_var($login, FILTER_VALIDATE_EMAIL)){
            try{
                //R?cup?re les infos du compte
                $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_WSDL_URL );
                $cwresult = $soap->__soapCall( self::COMPTEWEB_ACCOUNT_INFOS,array("parameters"=>array('email'=>$login)));
                $resultName = self::COMPTEWEB_ACCOUNT_INFOS_RESULT;
                $sso_user = $cwresult->$resultName;
            } catch (SoapFault $fault) {
                return false;
            }
        }
        return $sso_user;
    }

    static function checkLoginPwd( $host ,$cookie_name, $login, $password ) {

        try{
            $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_WSDL_URL );
            $cwresult = $soap->__soapCall(self::COMPTEWEB_IS_ACCOUNT_EXIST,array("parameters"=>array('email'=>$login)));
            $resultName = self::COMPTEWEB_IS_ACCOUNT_EXIST_RESULT;
            $cwexist = $cwresult->$resultName;

        } catch (SoapFault $fault) {
            return false;
        }
        if (!$cwexist)
        {
            return false;
        }
        else if ( $cwexist ) {
            //Authenticate cw
            try{
                $soapAuth = new SoapClient( $host . self::COMPTEWEB_AUTHENTICATION_WSDL_URL );
                $cwresult = $soapAuth->__soapCall( self::COMPTEWEB_AUTHENTICATION_AUTHENTICATE , array("parameters"=>array('login'=>$login, 'password'=>addslashes($password))));
                $resultName = self::COMPTEWEB_AUTHENTICATION_AUTHENTICATE_RESULT;
            } catch (SoapFault $fault) {
                return false;
            }
            if (!$cwresult->$resultName->Authenticated){
                //Mauvais password
                return false;
            }


            //$acwresult = $cwresult->$resultName->AccountData;

            //Creation objet CW
            //$ezUser = self::createAccountEzCW($acwresult);

            //set cookie
            $acwcookie = $cwresult->$resultName->CookieLDAP;
            if (!isset($acwcookie))
            {
                $acwcookie = (object) array("Name" => $cookie_name, "Value" => "ssodown", "Expires" => "", "Path" => "/", "Domain" => get_site_option('domaine_cookie_sso'), "Secure" => "");
            }
            if( $acwcookie->Expired )
            {
                // Set cookie as expired
                $acwcookie->Expires = 1;
            }
            else
            {
                if( strtotime( $acwcookie->Expires ) > time() )
                {
                    // If valid datetime has been given by Compte Web then use transform it in timestamp to create cookie
                    $acwcookie->Expires = strtotime( $acwcookie->Expires );
                }
                else
                {
                    // If invalid datetime then cookie expired with session
                    $acwcookie->Expires = 0;
                }
            }
            if (!setcookie($acwcookie->Name, $acwcookie->Value, $acwcookie->Expires, $acwcookie->Path, $acwcookie->Domain, $acwcookie->Secure, true)){
//                eZDebug::writeNotice( 'Creation du login SSO rat�' , 'eZAfnorLogin' );
            }
            return true;
        }

        return false;
    }
	
	static function GetEntiteConsentement($host, $mail, $entite, $langue){
        try{
            $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_CREATION_WSDL_URL );
            $params = array( "parameters" => array('requete' => (object) array("Email" => $mail, 'Entite' => $entite, 'Langue' => $langue)));
            $cwresult = $soap->__soapCall(self::COMPTEWEB_CONSENTEMENT_GET,$params);
            $resultName = self::COMPTEWEB_CONSENTEMENT_GET_RESULT;
            return $cwresult->$resultName;

        } catch (SoapFault $fault) {
            return false;
        }
    }
	
	static function UpdateConsentement($host, $mail, $consentements, $contexte){
        try{
            $soap = new SoapClient( $host . self::COMPTEWEB_ACCOUNT_CREATION_WSDL_URL );
			$obj = array("Consentements" => $consentements, 'Email' => $mail, 'Contexte' => $contexte);
            $params = array( "parameters" => array('requete' => (object) $obj));
            $cwresult = $soap->__soapCall(self::COMPTEWEB_CONSENTEMENT_UPDATE,$params);
            $resultName = self::COMPTEWEB_CONSENTEMENT_UPDATE_RESULT;
            return $cwresult->$resultName;

        } catch (SoapFault $fault) {
            return false;
        }
    }
	
	static function array_to_object($array) {
	  $obj = new stdClass;
	  foreach($array as $k => $v) {
		 if(strlen($k)) {
			if(is_array($v)) {
			   $obj->{$k} = self::array_to_object($v); //RECURSION
			} else {
			   $obj->{$k} = $v;
			}
		 }
	  }
	  return $obj;
	} 
	
}