<?php
/**
 *
 * @package Header_Login
 * @version 2.8.8
 */
/*
Plugin Name: afnorpass
Plugin URI:
Description: This plugin will automatically log a user into WordPress if they are logged into Afnor pass.
This allows for a user to log into Afnor pass and then be automatically logged into Wordpress, without having to navigate to the Admin Console.
Author: Bin LIU
Version: 1.1.0
Author URI: liu.bin@live.fr
*/

/*  Copyright 2012  Scott Weber/Matthew Ehle  (email : scweber@novell.com, mehle@novell.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
//Default Values
include_once(__DIR__ . '/afnorsso_class.php');
session_start();

add_action('plugins_loaded', 'afnorpass_setup', 99999);

include_once(__DIR__ . '/class/recaptchalib.php');
include_once(__DIR__ . '/class/UserAccessManager.class.php');
include_once(__DIR__ . '/class/UamUserGroup.class.php');
include_once(__DIR__ . '/class/UamAccessHandler.class.php');

/*
 * Functions start here
 */

/* Get options and setup filters & actions */
function afnorpass_setup()
{
    load_plugin_textdomain('afnorpass', false
        , dirname(plugin_basename(__FILE__)));
}

function af_menu()
{
    //Include the CSS and JS files
    wp_enqueue_style('afnorpass-stylesheet', plugins_url('css/afnorpass.css', __FILE__));
    wp_enqueue_script('afnorpass-javascript', plugins_url('js/afnorpass.js', __FILE__), array('jquery'), '1.0', true);

    //If multisite, then get the blog IDs
    if (is_multisite()) {
        global $wpdb;
        $blogList = $wpdb->get_results("SELECT blog_id, domain, path FROM " . $wpdb->blogs);
    }

    //Update the values in the database, send error message if all required fields not filled in.
    if (isset($_POST['afnorpass-save']) && $_POST['afnorpass-save']) {
        if ($_POST['af_mode'] != "" && $_POST['af_applicationID'] != "") {
            update_site_option('af_mode', $_POST['af_mode']);
            update_site_option('af_applicationID', $_POST['af_applicationID']);
            update_site_option('af_mailSubject', $_POST['af_mailSubject']);
            update_site_option('af_mailBody', $_POST['af_mailBody']);
            update_site_option('page_login', $_POST['page_login']);
            update_site_option('domaine_cookie_sso', $_POST['domaine_cookie_sso']);
            update_site_option('af_gc_privatekey', $_POST['af_gc_privatekey']);
            update_site_option('af_gc_sitekey', $_POST['af_gc_sitekey']);
            update_site_option('af_ws_url', $_POST['af_ws_url']);
            update_site_option('af_cookie_name', $_POST['af_cookie_name']);
            update_site_option('af_source_policy', $_POST['af_source_policy']);
            update_site_option('af_source_ws_url', $_POST['af_source_ws_url']);
            update_site_option('af_pass_forget_url', $_POST['af_pass_forget_url']);
						
            update_site_option('af_settingsSaved', 'true');

            ?>
            <div id="message" class="updated">
            <p><strong><?php _e('Settings Saved') ?></strong></p>
            </div>
            <?php
        } else {
            update_site_option('af_settingsSaved', 'false');

            ?>
            <div id="message" class="error">
                <p><strong><?php _e('Error Saving Settings:
Mode inscription/application ID.') ?> </strong></p>
            </div>
            <?php
        }
    }

    //Get the current values out of the database and fill in the view
    $af_mode = get_site_option('af_mode');
    $af_applicationID = get_site_option('af_applicationID');
    $af_mailSubject = get_site_option('af_mailSubject');
    // $af_mailBody = get_site_option('af_mailBody');
    $page_login = get_site_option('page_login');
    $af_gc_privatekey = get_site_option('af_gc_privatekey');
    $af_gc_sitekey = get_site_option('af_gc_sitekey');
    $af_ws_url = get_site_option('af_ws_url');
    $af_cookie_name = get_site_option('af_cookie_name');
    $domaine_cookie_sso = get_site_option('domaine_cookie_sso');
    $af_source_policy = get_site_option('af_source_policy');
    $af_source_ws_url = get_site_option('af_source_ws_url');
    $af_pass_forget_url = get_site_option('af_pass_forget_url');

    echo '<div class="wrap">';
    echo '<h2>' . __('afnorpass Options', 'afnorpass') . '</h2>';
    echo '</div>';
    ?>
    <p>
        <?php _e('The afnorpass plugin sets the WordPress attributes equal from compte web.'); ?>
    </p>

    <form method="post" id="header_login_save_options">

        <h3><?php _e('afnorpass Settings', 'afnorpass'); ?></h3>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><label for="auth-header"><strong><?php _e('Mode inscription*', 'afnorpass'); ?></strong></label>
                </th>
                <td>
                    <input type="radio" name="af_mode" id="af_mode-true" value="1" <?php if ($af_mode === '1') {
                        echo 'checked';
                    } ?> /> <label for="af_mode-true"><?php _e('Mode iframe', 'afnorpass'); ?></label>
                    <input type="radio" name="af_mode" id="af_mode-false" value="0" <?php if ($af_mode === '0') {
                        echo 'checked';
                    } ?> /> <label for="af_mode-false"><?php _e('Mode webservice', 'afnorpass'); ?></label>

                    <br/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('application ID*', 'afnorpass'); ?></strong></label></th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_applicationID" id="af_applicationID"
                           value="<?php echo $af_applicationID; ?>"/> (ex. : BIVI)
                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Sujet du mail*', 'afnorpass'); ?></strong></label></th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_mailSubject" id="af_mailSubject"
                           placeholder="Sujet du mail d'activation" value="<?php echo $af_mailSubject; ?>"/>
                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('URL page login', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="page_login" id="page_login"
                           value="<?php echo $page_login; ?>"/> (ex. : login ATTENTION, il faut créer la page login pour chaque site)
                </td>
            </tr>
			
			 <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Domaine cookie SSO', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="domaine_cookie_sso" id="domaine_cookie_sso"
                           value="<?php echo $domaine_cookie_sso; ?>"/> (ex. : ".afnor.org",".integ.afnor.org")
                </td>
            </tr>
			
            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Google reCAPTCHA - Clé secrète*', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_gc_privatekey" id="af_gc_privatekey"
                           value="<?php echo $af_gc_privatekey; ?>"/> (ex. : 6Lc2eCkTAAAAAOfj9z_U98bMFdQSP0TA0dXTWvEQ)
                </td>
            </tr>
			
			<tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Google reCAPTCHA - Clé du site*', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_gc_sitekey" id="af_gc_sitekey"
                           value="<?php echo $af_gc_sitekey; ?>"/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Url Webservice', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_ws_url" id="af_ws_url"
                           value="<?php echo $af_ws_url; ?>"/><br />
                    ex. : <li>recette : http://comptesweb-services.recette.integ.afnor.org</li> <li>
                        http://afnorpass-services.afnor.org</li>

                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('CW Nom du Cookie', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="text" name="af_cookie_name" id="af_cookie_name"
                           value="<?php echo $af_cookie_name; ?>"/><br />
                    ex. : <li>recette : lemonldaprecette</li> <li>prod : lemonldap_afnor</li>

                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Gestion des droits SOURCE', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="checkbox" name="af_source_policy" id="af_source_policy"
                           value="1" <?php if($af_source_policy == 1 ){echo "checked";} ?> />
                </td>
            </tr>

            <tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('URL Webservice SOURCE', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="input" name="af_source_ws_url" id="af_source_ws_url"
                           value="<?php echo $af_source_ws_url; ?>"/><br />
                    ex. : http://ws2.dev.integ.afnor.org/WsSource/WsSource.svc?wsdl

            </tr>
                </td>
			
			
			<tr valign="top">
                <th scope="row"><label
                        for="auth-header"><strong><?php _e('Lien Afnor Pass - Mot de passe oublié', 'afnorpass'); ?></strong></label>
                </th>

                <td class="ss-blog-new-user-role" style="display:">
                    <input type="input" name="af_pass_forget_url" id="af_pass_forget_url"
                           value="<?php echo $af_pass_forget_url; ?>"/><br />
                    Ex.<br />Prod : http://afnorpass.afnor.org/reset-password-request?returnUrl=
					<br />Recette : http://compteswebv2.recette.integ.afnor.org/reset-password-request?returnUrl=
					<br />Dev : http://compteswebv2.dev.integ.afnor.org/reset-password-request?returnUrl=

                </td>
            </tr>

            <!--                <tr valign="top">
                    <th scope="row"><label for="auth-header"><strong><?php /*_e('Mail contenu*','afnorpass'); */ ?></strong></label></th>

                    <td class="ss-blog-new-user-role"  style="display:">
                        <textarea name="af_mailBody" id="af_mailBody">
                            <?php /*if($af_mailBody) echo $af_mailBody;
                            else echo "Bonjour {FULLNAME},
                            Merci de vous être inscrit sur notre site {APPLICATION}. Cliquez {VALIDATION_LINK} pour activer votre compte";*/ ?>
                        </textarea>
                    </td>
                </tr>-->

        </table>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">
                    <strong>* Required</strong>
                </th>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" name="afnorpass-save" class="button-primary"
                   value="<?php _e('Save Changes', 'afnorpass'); ?>"/>
        </p>
    </form>
    <?php
} //End af_menu

//Set up Plugin Menu
function af_plugin_menu()
{//Set up the plugin menu

    if (is_multisite()) {//Is multisite?
        add_submenu_page('settings.php', __('afnorpass Options', 'Afnorpass'), __('Afnorpass', 'Afnorpass'), 'manage_options', 'afnorpass', 'af_menu');
    } else {
        add_submenu_page('options-general.php', __('afnorpass Options', 'Afnorpass'), __('Afnorpass', 'Afnorpass'), 'edit_plugins', basename(__FILE__), 'af_menu');
    }

   

} //End af_plugin_menu

function af_add_to_blog($userdata, $blog_id, $new_user)
{
    if (is_multisite()) { // if multisite
        // if existing user, then get their current role for this blog
        switch_to_blog($blog_id);
        $user = new WP_User($userdata['ID'], $blog_id);
        if (!empty($user->roles) && is_array($user->roles)) {
            foreach ($user->roles as $role) {
                $userdata['role'] = $role;
            }
        }
        wp_update_user($userdata);
        add_user_to_blog($blog_id, $userdata['ID'], $userdata['role']);
    } else if (!is_multisite() && $new_user == 0) {
        $user = get_userdata($userdata['ID']);
        $userdata['role'] = implode(', ', $user->roles);
        wp_update_user($userdata);
    }
} //End af_add_to_blog

//Create User
function af_create_user($user_id, $user_login, $user_email, $user_firstname, $user_lastname, $user_nicename, $user_displayname, $new_user_role, $blog_id)
{
    $userdata = af_create_new_user($user_id, $user_login, $user_email, $user_firstname, $user_lastname, $user_nicename, $user_displayname, $new_user_role, $blog_id);
    wp_authenticate($userdata['user_login'], NULL);
    wp_set_auth_cookie($user_id, false); //Set the Authorization Cookie
    do_action('wp_login', $userdata['user_login'], new WP_User($userdata['ID']));
    return $userdata;
} //End af_create_user

//Create a new user with the Header Data
function af_create_new_user($user_id, $user_login, $email, $fname, $lname, $user_nicename, $user_displayname, $user_role, $blog_id)
{
    //Populate the userdata array
    $userdata = array(
        'ID' => $user_id,
        'user_login' => $user_login,
        'user_email' => $email,
        'role' => $user_role);

    if ($fname != "") {
        $userdata['first_name'] = $fname;
    }
    if ($lname != "") {
        $userdata['last_name'] = $lname;
    }
    if ($user_nicename != "") {
        $userdata['user_nicename'] = $user_nicename;
    }
    if ($user_displayname != "") {
        $userdata['display_name'] = $user_displayname;
    }

    $userdata['ID'] = wp_insert_user($userdata);
    af_add_to_blog($userdata, $blog_id, 1);

    return $userdata;
} //End af_create_new_user

//Update User
function af_update_user($user_id, $user_login, $user_email, $user_firstname, $user_lastname, $user_nicename, $user_displayname, $new_user_role, $blog_id)
{
    $userdata = af_update_existing_user($user_id, $user_login, $user_email, $user_firstname, $user_lastname, $user_nicename, $user_displayname, $new_user_role, $blog_id);
    wp_authenticate($userdata['user_login'], NULL);
    wp_set_auth_cookie($user_id, false);
    do_action('wp_login', $userdata['user_login'], new WP_User($userdata['ID']));
    show_admin_bar(true);
} //End af_update_user

//Update the current user with the afnor Data
function af_update_existing_user($user_id, $user_login, $email, $fname, $lname, $user_nicename, $user_displayname, $user_role, $blog_id)
{
    //Populate the userdata array
    $userdata = array(
        'ID' => $user_id,
        'user_login' => $user_login,
        'user_email' => $email,
        'role' => $user_role);

    if ($fname != "") {
        $userdata['first_name'] = $fname;
    }
    if ($lname != "") {
        $userdata['last_name'] = $lname;
    }
    if ($user_nicename != "") {
        $userdata['user_nicename'] = $user_nicename;
    }
    if ($user_displayname != "") {
        $userdata['display_name'] = $user_displayname;
    }

    af_add_to_blog($userdata, $blog_id, 0);

    return $userdata;
} //End af_update_existing_user

function af_authenticate_username($user, $username, $pass)
{//var_dump($user);exit;
    if(is_array($user)){
        $user = new WP_User($user['ID']);
        return $user;
    }else{
        return;
    }

} //End af_authenticate_username

function update_source_policy($user_id, $user_login){
    //vérification source
    $client = new SoapClient(get_site_option('af_source_ws_url'));
    $result = $client->__soapCall( 'GetProfilesExtranet',array("parameters"=>array('email'=>$user_login)));
    $roles = $result->GetProfilesExtranetResult;
    global $wpdb;
    //tout au début, on vide tous ces droits
    $wpdb->query("DELETE FROM wp_uam_accessgroup_to_object WHERE object_type='user' AND object_id='" . $user_id . "'");
    //on récupère les droits et distribue les droits
    foreach ($roles->string as $role) {
        if(!$role){continue;}
        $r = $aDbObjects = $wpdb->get_row(
            "SELECT * FROM wp_uam_accessgroups WHERE groupname = '" . $role . "'"
        );
        if ($r) {
            $wpdb->query("INSERT INTO wp_uam_accessgroup_to_object (object_type,object_id,group_id) VALUES ('user','" . $user_id . "','" . $r->ID . "')");
        }
    }
}
function af_user_login($do_redirect = false)
{
    $current_user = wp_get_current_user();
	$urlQuestionnaire = get_bloginfo("siteurl")."/questionnaire";
	$urlQuestionnaire = $_POST['redirect_to'];
	
    if (!$current_user->user_login) {
        $sso_user = AfnorSSO::checkSSO(get_site_option('af_ws_url'),get_site_option('af_cookie_name'));
        if($_GET['afdebug'] == 1){
            var_dump($sso_user);
        }
		
        if (is_object($sso_user) && filter_var($sso_user->cw_email, FILTER_VALIDATE_EMAIL)) {
            $new_user_role = get_site_option('af_defaultRole', AfnorSSO::AF_NEWUSERROLE);

            //s'il y a un compte sso
            $user_login = $sso_user->cw_email;
            $user_id = username_exists($user_login);

            if (!$user_id) {
                $user_id = email_exists($user_login);
                if ($user_id) {
                    af_update_existing_user($user_id, $user_login, $user_login, $sso_user->cw_prenom, $sso_user->cw_nom, $sso_user->cw_nom, $sso_user->cw_nom, $new_user_role, 0);
                }
            }
            //var_dump($user_id);exit;
            if ($user_id) { // Already a WP User
                //le compte existe dans CW et aussi WP. login!
                wp_set_current_user($user_id, $user_login);
                wp_set_auth_cookie($user_id);
                do_action('wp_login', $user_login);
 
                //quand on a configuré les droits sources
                if(get_site_option('af_source_policy') == 1) {
                    update_source_policy($user_id, $user_login);
                }

                $redirect_to = ($_POST['redirect_to'] == get_admin_url()) ? get_home_url() : $_POST['redirect_to'];
                //wp_redirect($redirect_to); //Redirect back to current location
				wp_redirect($urlQuestionnaire."?r=1");
                
				// exit;
            } else {
                //le compte existe dans CW, mais pas dans WP. créer le compte dans WP !
                // if(!is_multisite()) {
                $user = af_create_user($user_id, $user_login, $user_login, $sso_user->cw_prenom, $sso_user->cw_nom, $sso_user->cw_nom, $sso_user->cw_prenom . ' '.$sso_user->cw_nom, $new_user_role, 0);

                if(get_site_option('af_source_policy') == 1){
                    update_source_policy($user['ID'], $user_login);
                }

				/*
                $redirect_to = ($_POST['redirect_to'] == get_admin_url()) ? get_home_url() : $_POST['redirect_to'];
                if(!$redirect_to)$redirect_to = $_SERVER['REQUEST_URI'];
                wp_redirect($redirect_to); //Redirect back to current location
				*/
				
				 wp_redirect($urlQuestionnaire."?r=1");
				 
               // exit;
            }
        } else {
            $redirect_to = ($_POST['redirect_to'] == get_admin_url()) ? get_home_url() : $_POST['redirect_to'];

            // var_dump( __LINE__ . $redirect_to);exit;
            if ($do_redirect && $redirect_to) {
                //wp_redirect($redirect_to);
                wp_redirect($urlQuestionnaire."?r=1");
              //  exit;
            }
        }
    }

    /*$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $theID = url_to_postid($actual_link);
    $not_do_redirect = (str_replace('/','',$_SERVER[REQUEST_URI]) == get_site_option('page_login') && get_site_option('page_login') );
    //var_dump(__LINE__);var_dump(str_replace('/','',$_SERVER[REQUEST_URI]));var_dump(get_site_option('page_login') );exit;
    if($not_do_redirect) {
    }
    elseif( $theID > 0){

            if (class_exists("UserAccessManager")) {
                $oUserAccessManager = new UserAccessManager();
            }
            $redirect_to = get_site_option('page_login') ? get_site_option('page_login') : "/wp-login.php?redirect_to=/&reauth=1";
            $r = $oUserAccessManager->isValidateAccess($theID, $redirect_to);
    }*/
}

//Activation Hook
function af_activate()
{
    //Set Default Settings
    update_site_option('af_mode', '');
    update_site_option('af_applicationID', '');
    update_site_option('af_mailSubject', '');
    update_site_option('af_mailBody', '');
    update_site_option('page_login', '');
    update_site_option('af_gc_privatekey', '');
    update_site_option('af_gc_sitekey', '');
    update_site_option('af_ws_url', '');
    update_site_option('af_cookie_name', '');
    update_site_option('af_source_policy', '');
    update_site_option('af_source_ws_url', '');
    update_site_option('af_pass_forget_url', '');
   
    update_site_option('af_settingsSaved', '');

    if (is_multisite()) {
        global $wpdb;
        $blogList = $wpdb->get_results("SELECT blog_id, domain, path FROM " . $wpdb->blogs);
        foreach ($blogList as $blog) {
            update_site_option('af_createNewUser' . $blog->blog_id, '');
            update_site_option('af_defaultRole' . $blog->blog_id, AfnorSSO::AF_NEWUSERROLE);
        }
    } else {
        update_site_option('af_createNewUser', '');
        update_site_option('af_defaultRole', AfnorSSO::AF_NEWUSERROLE);
    }
} //End af_activation_hook
register_activation_hook(__FILE__, 'af_activate');

//Deactivation Hook
function af_uninstall()
{
    delete_site_option('af_mode');
    delete_site_option('af_applicationID');
    delete_site_option('af_mailSubject');
    delete_site_option('af_mailBody');
    delete_site_option('page_login');
    delete_site_option('af_gc_privatekey');
    delete_site_option('af_gc_sitekey');
    delete_site_option('af_id_prod');
    
    delete_site_option('af_settingsSaved');

    if (is_multisite()) {
        global $wpdb;
        $blogList = $wpdb->get_results("SELECT blog_id, domain, path FROM " . $wpdb->blogs);
        foreach ($blogList as $blog) {
            delete_site_option('af_createNewUser' . $blog->blog_id);
            delete_site_option('af_defaultRole' . $blog->blog_id);
        }
    } else {
        delete_site_option('af_createNewUser');
        delete_site_option('af_defaultRole');
    }
} //End af_deactivation_hook
register_uninstall_hook(__FILE__, 'af_uninstall');

//Action Hooks
add_action('admin_menu', 'af_plugin_menu');
add_action('network_admin_menu', 'af_plugin_menu');

add_action('admin_menu', function() {
    add_options_page( __('afnorpass Options', 'Afnorpass'), __('Afnorpass', 'Afnorpass'), 'manage_options', 'afnorpass-plugin', 'afnorpass_plugin_page' );
});


add_action( 'admin_init', function() {
    register_setting( 'afnorpass-plugin-settings', 'login-background-image' );
    register_setting( 'afnorpass-plugin-settings', 'cgu-fr' );
    register_setting( 'afnorpass-plugin-settings', 'conf-fr' );
    register_setting( 'afnorpass-plugin-settings', 'rgpd-3-fr' );
    register_setting( 'afnorpass-plugin-settings', 'cgu-en' );
    register_setting( 'afnorpass-plugin-settings', 'conf-en' );
    register_setting( 'afnorpass-plugin-settings', 'rgpd-3-en' );
});
 
 function af_login_background_url() {
	$option = get_option('login-background-image');
	if (empty($option) || !$option) {
		return false;
	}
	if ('default' === $option) {
		return plugins_url('img/afnor-login-background-default.jpg', __FILE__);
	} else {
		$image_attributes = wp_get_attachment_image_src($option, array(1920, 1080));
		return $image_attributes[0];
	}
 }
 
 function af_image_uploader( $name, $width, $height ) {

    // Set variables
    $options = get_option($name);
    $default_image = plugins_url('img/afnor-login-background-default.jpg', __FILE__);

    if ( $options && !empty( $options ) ) {
		if ('default' === $options) {
			$src = $default_image;
			$value = 'default';
		} else {
			$image_attributes = wp_get_attachment_image_src( $options, array( $width, $height ) );
			$src = $image_attributes[0];
			$value = $options;
		}
    } else {
        $src = '';
        $value = '';
    }

    $text = __( 'Upload', RSSFI_TEXT );

    // Print HTML field
	$display =  "" === $src ? "style=\"display:none\"" : "";
    echo '
        <div class="upload">
            <img ' . $display . ' data-src="' . $default_image . '" src="' . $src . '" width="' . $width . 'px" height="' . $height . 'px" />
            <div>
                <input type="hidden" name="' . $name . '" id="' . $name . '" value="' . $value . '" />
                <button type="submit" class="upload_image_button button">' . $text . '</button>
                <button type="submit" class="default_image_button button">Default image</button>
                <button type="submit" class="remove_image_button button">&times;</button>
            </div>
        </div>
    ';
}
 
function afnorpass_plugin_page() {
  ?>
    <div class="wrap">
      <form action="options.php" method="post">
 
        <?php
          settings_fields( 'afnorpass-plugin-settings' );
          do_settings_sections( 'afnorpass-plugin-settings' );
        ?>
        <h2><?php echo __('afnorpass Options', 'Afnorpass'); ?></h2>

        <table width="100%">
			<tr>
                <th>Image d'arrière plan</th>
                <td>
					<?php af_image_uploader( 'login-background-image', $width = 115, $height = 115 ); ?>
				</td>
            </tr>
            <tr>
                <th width="200"><h3>Français</h3></th>
                <td></td>
            </tr>
            <tr>
                <th>Lien<br />Conditions d'utilisation</th>
                <td><input type="text" placeholder="" name="cgu-fr" value="<?php echo esc_attr( get_option('cgu-fr') ); ?>" style="width:70%" /></td>
            </tr>
            <tr>
                <th>Lien<br />Règles de confidentialité</th>
                <td><input type="text" placeholder="" name="conf-fr" value="<?php echo esc_attr( get_option('conf-fr') ); ?>" style="width:70%" /></td>
            </tr>
			<tr>
                <th>RGPD<br />Texte charte</th>
                <td>
					<?php
					$settings = array( 'media_buttons' => false, 'textarea_rows' => 8, 'wpautop' => true );
					wp_editor( get_option('rgpd-3-fr'), 'rgpd-3-fr', $settings );
					?>
				</td>
            </tr>

            <tr>
                <th width="200"><h3>Anglais</h3></th>
                <td></td>
            </tr>
             <tr>
                <th>Lien<br />Conditions d'utilisation</th>
                <td><input type="text" placeholder="" name="cgu-en" value="<?php echo esc_attr( get_option('cgu-en') ); ?>" style="width:70%" /></td>
            </tr>
            <tr>
                <th>Lien<br />Règles de confidentialité</th>
                <td><input type="text" placeholder="" name="conf-en" value="<?php echo esc_attr( get_option('conf-en') ); ?>" style="width:70%" /></td>
            </tr>
			<tr>
                <th>RGPD<br />Texte charte</th>
				<td>
					<?php
					$settings = array( 'media_buttons' => false, 'textarea_rows' => 8, 'wpautop' => true );
					wp_editor( get_option('rgpd-3-en'), 'rgpd-3-en', $settings );
					?>
				</td>
            </tr>

            <tr>
                <td><?php submit_button(); ?></td>
            </tr>


        </table>
       
 
      </form>
	  
	  
	  
    </div>
  <?php
}

add_action('admin_footer', function() { 
	?>
    <script>
	jQuery(document).ready(function ($) {
		// The "Upload" button
		$('.upload_image_button').click(function() {
			var send_attachment_bkp = wp.media.editor.send.attachment;
			var button = $(this);
			wp.media.editor.send.attachment = function(props, attachment) {
				$(button).parent().prev().attr('src', attachment.url);
				$(button).parent().prev().show();
				$(button).prev().val(attachment.id);
				wp.media.editor.send.attachment = send_attachment_bkp;
			}
			wp.media.editor.open(button);
			return false;
		});

		// The "Remove" button (remove the value from input type='hidden')
		$('.remove_image_button').click(function() {
			var answer = confirm('Are you sure?');
			if (answer == true) {
				$(this).parent().prev().attr('src', '');
				$(this).parent().prev().hide();
				$(this).prev().prev().prev().val('');
			}
			return false;
		});
		
		$('.default_image_button').click(function() {
			var src = $(this).parent().prev().attr('data-src');
			$(this).parent().prev().attr('src', src);
			$(this).parent().prev().show();
			$(this).prev().prev().val('default');
			return false;
		});
	});
    </script>
    <?php
});
 add_action('admin_enqueue_scripts', function(){
    /*
    if possible try not to queue this all over the admin by adding your settings GET page val into next
    if( empty( $_GET['page'] ) || "my-settings-page" !== $_GET['page'] ) { return; }
    */
    wp_enqueue_media();
});

// fin option page


function af_sso_login()
{
    if (!empty($_POST) && isset($_POST['log']) && isset($_POST['pwd'])) {
        $auth = AfnorSSO::checkLoginPwd(get_site_option('af_ws_url'),get_site_option('af_cookie_name'),$_POST['log'], $_POST['pwd']);      
	//var_dump(get_site_option('af_ws_url'),get_site_option('af_cookie_name'),$_POST,$auth);exit;
        if ($auth === true) {
			if (!isset($_POST['redirect_to'])) {
				$_POST['redirect_to'] = get_home_url();
			}
            $redirect_to = ($_POST['redirect_to'] == get_admin_url()) ? get_home_url() : $_POST['redirect_to'];
			
			if (strpos($redirect_to,'questionnaire.htm')) {
				$redirect_to = add_query_arg(array('email' => $_POST['log'], 'key' => md5(strtolower($_POST['log']))), $redirect_to);
				wp_redirect( $redirect_to );
				exit();
			}
			
			wp_redirect($redirect_to."?r=1");
			
        }elseif(get_site_option('page_login')){
			if (isset($_POST['redirect_to'])) {
				$redirect_to = '&redirect_to=' . $_POST['redirect_to'];
			} else {
				$redirect_to = '';
			}
            wp_redirect(get_blog_details()->path . get_site_option('page_login') . "?form_error=1" . $redirect_to);		
        }
    } elseif (!empty($_GET["action"]) && $_GET['action'] == 'lostpassword') {
		$from = get_home_url();
		if (isset($_GET['redirect_to'])) {
			$from = $_GET['redirect_to'];
		}
        $redirect_to = get_site_option('af_pass_forget_url') . $from;
        wp_redirect($redirect_to);
    } elseif (isset($_GET['action']) && $_GET['action'] == 'logout') {
		
        setcookie(get_site_option('af_cookie_name'), "", time() - 3600, null, null, null, true);
        setcookie(get_site_option('af_cookie_name'), '', time() - 3600, "/", get_site_option('domaine_cookie_sso'), true, true);
		
        //Suppression des sessions
        session_unset();
        session_regenerate_id();
        if (isset($_SESSION))
            session_destroy();
				
        //die("no cookie");
    }elseif(get_site_option('page_login')){
        //wp_redirect($redirect_to);
        wp_redirect(get_blog_details()->path . get_site_option('page_login'));
    }
}

$settingsSaved = get_site_option('af_settingsSaved', 'false');
if (strstr(wp_login_url(), $_SERVER['PHP_SELF'])) {
    //if it's page login
    add_action('init', 'af_sso_login', 2);
} else {

    add_action('init', 'af_user_login', 2);

    //add_filter('the_posts', array($oUserAccessManager, 'showPost'));

    add_action('wp_logout', 'redirect_home');
    //add_action('wp_before_admin_bar_render', 'af_admin_bar_render', 1);

    //Remove Filter
    remove_filter('authenticate', 'wp_authenticate_username_password', 20, 3);

    //Add Filter
    add_filter('authenticate', 'af_authenticate_username', 10, 3);
}

// Add Password, Repeat Password and Are You Human fields to WordPress registration form
// http://wp.me/p1Ehkq-gn
add_action('register_form', 'afpass_show_extra_register_fields');
function afpass_show_extra_register_fields()
{
    ?>
    <style>
        #login form p:first-child {
            display: none;
        }
    </style>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <script>
        $(document).ready(function () {
            $('#login form').submit(function () {
                $('#user_login').val($('#user_email').val())
            });
        });
    </script>


<!--    <script src='https://www.google.com/recaptcha/api.js'></script>
-->
    <p>
        <label for="civilite-m">Civilité *<br/>
            <input id="civilite-m" class="radio" type="radio" value="M." name="civilite" checked/> Monsieur
            <input id="civilite-mme" class="radio" type="radio" value="Mme" name="civilite"/> Madame
            <input id="civilite-mlle" class="radio" type="radio" value="Mlle" name="civilite"/> Mademoiselle
        </label>
    </p><br/>

    <p>
        <label for="civilite-m">Prénom *<br/>
            <input id="prenom" class="input" type="text" tabindex="30" size="25" value="" name="prenom"/>
        </label>
    </p>

    <p>
        <label for="civilite-m">Nom *<br/>
            <input id="nom" class="input" type="text" tabindex="30" size="25" value="" name="nom"/>
        </label>
    </p>

    <p>
        <label for="password">Mot de passe *<br/>
            <input id="password" class="input" type="password" tabindex="30" size="25" value="" name="password"/>
        </label>
    </p>
    <p>
        <label for="repeat_password">Rétaper mot de passe *<br/>
            <input id="repeat_password" class="input" type="password" tabindex="40" size="25" value=""
                   name="repeat_password"/>
        </label>
    </p>

    <?php
    $page_login = get_site_option('page_login');

    ?>

<!--    <div class="g-recaptcha" data-sitekey="<?php /*echo $page_login */?>"></div>
-->
    <?php
}

function message_after_register()
{
    echo '<p class="message register">Veuillez valider votre compte d\'activation</p>';
}


// Check the form for errors
add_action('register_post', 'ts_check_extra_register_fields', 10, 3);
function ts_check_extra_register_fields($login, $email, $errors)
{
    $e = 0;
    
    if (!$_POST['nom']) {
        $e = 1;
        $errors->add('nom_empty', __('<strong>ERROR</strong>: The last name field is empty.','afnorpass'));
    }
    if (!$_POST['prenom']) {
        $e = 1;
        $errors->add('prenom_empty', __('<strong>ERROR</strong>: The first name field is empty.','afnorpass'));
    }
    if ($_POST['password'] !== $_POST['repeat_password']) {
        $e = 1;
        $errors->add('passwords_not_matched', __('<strong>ERROR</strong>: The password and confirmation password do not match.','afnorpass'));
    }
    if (strlen($_POST['password']) < 7) {
        $e = 1;
        $errors->add('password_too_short', '<strong>ERREUR</strong>: Le mot de passe doit contenir plus de 8 caractères, être composé d\'au moins une minuscule, une majuscule, un chiffre et un caractère spécial. Il ne doit pas contenir votre nom, prénom et des éléments de votre adresse email.');
    }

    if ($_POST['cgu'] != 1) {
        $e = 1;
        $errors->add('cgu_empty', __('<strong>ERROR</strong>: You must accept the terms of use.','afnorpass'));
    }
    
    $secret = get_site_option('af_gc_privatekey');
    //$reCaptcha = new ReCaptcha($secret);
   /* if (isset($_POST["g-recaptcha-response"])) {
        $resp = $reCaptcha->verifyResponse(
            $_SERVER["REMOTE_ADDR"],
            $_POST["g-recaptcha-response"]
        );
        if ($resp != null && $resp->success) {

        } else {
            $e = 1;
            $errors->add('captcha_no_valide', "<strong>ERROR</strong>: Captcha non valide");
        }
    } else {
        $e = 1;
        $errors->add('captcha_no_valide', "<strong>ERROR</strong>: Captcha vide");
    }*/

    if ($e == 0) {
        $afnorpass_info = array();
        $afnorpass_info["applicationID"] = get_site_option('af_applicationID');
        $afnorpass_info["applicationLibelle"] = get_site_option('af_applicationID');
        $afnorpass_info["authenticationKey"] = 'cw123';
        $afnorpass_info["fonction"] = 'fct_autre';
        $afnorpass_info["email"] = $_POST['user_email'];
        $afnorpass_info["titre"] = $_POST['civilite'];
        $afnorpass_info["nom"] = $_POST['nom'];
        $afnorpass_info["prenom"] = $_POST['prenom'];
        $afnorpass_info["role"] = 'ROL_AUTRE';
        $afnorpass_info["telephone"] = '0';
        $afnorpass_info["lang"] = (get_current_blog_id() == 2) ? 'en' : 'fr';

        $afnorpass_info["mailSubject"] = ($afnorpass_info["lang"] == 'fr') ? get_site_option('af_mailSubject') : "Please activate your account";

        //  $afnorpass_info["mailBody"] = get_site_option('af_mailBody');
        $afnorpass_info["password"] = $_POST['password'];
        //$afnorpass_info["returnUrl"] = get_home_url();
		// anthony
		
        //$afnorpass_info["returnUrl"] = get_bloginfo("siteurl")."/questionnaire";
		if(isset($_POST['from']) && !empty($_POST['from'])){
			$afnorpass_info["returnUrl"] = $_POST['from'];

		}else{
			$afnorpass_info["returnUrl"] = get_bloginfo("siteurl");
		}
        
		
		$afnorpass_info["countdown"] = "false";
        $res = AfnorSSO::createAccount(get_site_option('af_ws_url'),$afnorpass_info);
         // var_dump($res);exit;
        if ($res[0]) {
            // le compte a été créé dans afnorpass, mais on ne crée rien avant l'activation
            $redirect_to = wp_login_url() . '?checkemail=registered';
            wp_redirect($redirect_to);
           // exit;
        } else {
            //msg erreur
            $errors->add('error_compte_web', "<strong>ERROR</strong>: " . $res[1]);
        }
    }
}

add_action('user_register', 'ts_register_extra_fields', 100);
function ts_register_extra_fields($user_id)
{


    $userdata = array();
    $userdata['ID'] = $user_id;
    if ($_POST['password'] !== '') {
        $userdata['user_pass'] = $_POST['password'];
    }
    $new_user_id = wp_update_user($userdata);

}

add_filter('gettext', 'ts_edit_password_email_text');
function ts_edit_password_email_text($text)
{
    if ($text == 'A password will be e-mailed to you.') {
        $text = 'If you leave password fields empty one will be generated for you. Password must be at least seven characters long.';
    }
    return $text;
}

// pour multisite :
add_action('before_signup_form', 'afpass_validate');
function afpass_validate()
{
    echo "
    <script>
		jQuery(document).ready(function(){
            jQuery('form#setupform').hide();
		});
    </script>
    ";
    $error = 0;
    if ($_POST) {
        if ($_POST['user_name'] != $_POST['user_email']) {
            $error = 1;
        }
        $user_email = sanitize_email($_POST['user_email']);
        if (is_email_address_unsafe($user_email)) {
            $error = 2;
        }
        if ($_POST && !$_POST['nom']) {
            $error = 3;
        }
        if ($_POST && !$_POST['prenom']) {
            $error = 4;
        }
        if ($_POST && !$_POST['rgpd_3']) {
            $error = 5;
        }
        if ($_POST && $_POST['password'] !== $_POST['repeat_password']) {
            $error = 6;
        }
        if ($_POST && strlen($_POST['password']) < 7) {
            $error = 7;
        }
       
		if ($_POST && !$_POST["g-recaptcha-response"]) {
			$error = 8;
		}
	}
	
    if ($_POST && !$error) {
        $afnorpass_info = array();
        $afnorpass_info["applicationID"] = get_site_option('af_applicationID');
        $afnorpass_info["applicationLibelle"] = get_site_option('af_applicationID');
        $afnorpass_info["authenticationKey"] = 'cw123';
        $afnorpass_info["fonction"] = 'fct_autre';
        $afnorpass_info["email"] = $_POST['user_email'];
        $afnorpass_info["titre"] = $_POST['civilite'];
        $afnorpass_info["nom"] = $_POST['nom'];
        $afnorpass_info["prenom"] = $_POST['prenom'];
        $afnorpass_info["role"] = 'ROL_AUTRE';
        $afnorpass_info["telephone"] = '0';
        $afnorpass_info["mailSubject"] = get_site_option('af_mailSubject');
        $afnorpass_info["lang"] = (get_current_blog_id() == 2) ? 'en' : 'fr';
        
        //  $afnorpass_info["mailBody"] = get_site_option('af_mailBody');
        $afnorpass_info["password"] = $_POST['password'];
        //$afnorpass_info["returnUrl"] = get_home_url();
		
		
	    //$afnorpass_info["returnUrl"] = get_bloginfo("siteurl")."/questionnaire";
		
		if(isset($_POST['from']) && !empty($_POST['from'])){
			$afnorpass_info["returnUrl"] = $_POST['from'];

		}else{
			$afnorpass_info["returnUrl"] = get_bloginfo("siteurl");
		}

        $res = AfnorSSO::createAccount(get_site_option('af_ws_url'), $afnorpass_info);

        if ($res[0]) {
                    // Consentement relance commercial entité AFNOR
                    if (isset($_POST['rgpd_1']) && $_POST['rgpd_1']) {
                        $afnor_com = true;
                    } else {
                        $afnor_com = false;
                    }
                    
                    if (isset($_POST['rgpd_2']) && $_POST['rgpd_2']) {
                        $other_com = true;
                    } else {
                        $other_com = false;
                    }
                    
                    if (isset($_POST['rgpd_3']) && $_POST['rgpd_3']) {
                        $afnor_charte = true;
                    } else {
                        $afnor_charte = false;
                    }
                    
                    $consentement_to_up = [];
                    $consentement_to_up[] = array('ConsentementRequest' => array('Entite' => 'AFNOR', 'Consentement' => $afnor_com, 'TypeConsentement' => 'RELANCE_COMMERCIALE'));
                    
                    $consentement_to_up[] = array('ConsentementRequest' => array('Entite' => 'AFNOR_CERTIFICATION', 'Consentement' => $other_com, 'TypeConsentement' => 'RELANCE_COMMERCIALE'));
                    $consentement_to_up[] = array('ConsentementRequest' => array('Entite' => 'AFNOR_COMPETENCES', 'Consentement' => $other_com, 'TypeConsentement' => 'RELANCE_COMMERCIALE'));
                    $consentement_to_up[] = array('ConsentementRequest' => array('Entite' => 'AFNOR_INTERNATIONAL', 'Consentement' => $other_com, 'TypeConsentement' => 'RELANCE_COMMERCIALE'));

                    $consentement_to_up[] = array('ConsentementRequest' => array('Entite' => 'AFNOR', 'Consentement' => $afnor_charte, 'TypeConsentement' => 'CHARTE'));

                    foreach($consentement_to_up as $i=>$consent){
                        AfnorSSO::UpdateConsentement(get_site_option('af_ws_url'), $_POST['user_email'], $consentement_to_up[$i], strtoupper(get_site_option('af_applicationID')));
                    }
                    			
            $result = wpmu_validate_blog_signup( $_POST['blogname'], $_POST['blog_title'] );
            $domain = $result['domain'];
            $path = $result['path'];
            $blog_title = $result['blog_title'];

            af_confirm_blog_signup($domain, $path, $blog_title);
            get_footer('wp-signup');
            exit;
        } else {
            $_POST['error'] = $res[1];
        }
    }
}


function af_confirm_blog_signup($domain, $path, $blog_title, $user_name = '', $user_email = '', $meta = array())
{
	$container_style = array();
	if (af_login_background_url()) {
		$container_style[] = 'background-image:url('.af_login_background_url().')';
	}
	$container_style = empty($container_style) ? '' : 'style="'.implode(';', $container_style).'"';
	?>
	<div class="afnor-login" <?php echo $container_style ?>>
		<div class="afnor-signup-wrapper">
			<h2 class="signup-title"><?php _e( 'afnor_register_confirmation_title','afnorpass' ); ?></h2>
			<div class="signup-text"><?php _e( 'afnor_register_confirmation_texte','afnorpass' ) ?></div>
		</div>
	</div>
	<?php
	/** This action is documented in wp-signup.php */
	do_action( 'signup_finished' );
}

add_action('signup_extra_fields', 'afpass_signup_show_extra_register_fields');
function afpass_signup_show_extra_register_fields($errors)
{
	$blogInstance   = MslsBlogCollection::instance()->get_current_blog();
	$langue 		= $blogInstance->get_language();


    if ($_POST && !$_POST['nom']) {
        $errors->add('nom_empty', __('<strong>ERROR</strong>: The last name field is empty.','afnorpass'));
    }
    if ($_POST && !$_POST['prenom']) {
        $errors->add('prenom_empty', __('<strong>ERROR</strong>: The first name field is empty.','afnorpass'));
    }
    
    if ($_POST && $_POST['password'] !== $_POST['repeat_password']) {
        $errors->add('passwords_not_matched', __('<strong>ERROR</strong>: The password and confirmation password do not match.','afnorpass'));
    }
    if ($_POST && strlen($_POST['password']) < 7) {
        $errors->add('password_too_short', '<strong>ERREUR</strong>: Le mot de passe doit contenir plus de 8 caractères, être composé d\'au moins une minuscule, une majuscule, un chiffre et un caractère spécial. Il ne doit pas contenir votre nom, prénom et des éléments de votre adresse email.');
    }
    
   
    $re = '/^(?=.*\W)(?=.*[0-9])(?=.*[A-Z]).{8,}$/';;
   
    if($_POST && !preg_match($re, $_POST['password']))
        $errors->add('password_too_short', '<strong>ERREUR</strong>: Le mot de passe doit contenir plus de 8 caractères, être composé d\'au moins une minuscule, une majuscule, un chiffre et un caractère spécial. Il ne doit pas contenir votre nom, prénom et des éléments de votre adresse email.');
    

    if ($_POST && !$_POST['rgpd_3']) {
        $errors->add('rgpd_3_empty', __('<strong>ERROR</strong>: You must accept the terms of use.','afnorpass'));
    }

	$from = "";
	if($_GET["from"])
		$from = $_GET["from"];
	
	if($_POST["from"])
		$from = $_POST["from"];
	
	if(empty($from)) {
		$from = '';
	}
	
    if ($_POST && $_POST['user_email']) {
        if(AfnorSSO::isAccountExists(get_site_option('af_ws_url'), $_POST['user_email'])){
			if($langue == "fr_FR"){
				//francais
				$strErreurEmailExistant = "Un compte existe déjà avec cette adresse email.<br class='force'><a href='".get_site_option('af_pass_forget_url') . $from."'>Vous pouvez réinitialiser votre mot de passe.</a>";
			} else {
				//anglais
				$strErreurEmailExistant = "Account already exists with your email.<br class='force'><a href='".get_site_option('af_pass_forget_url') . $from."'>Forgot your Password? </a>";
			}
            echo "
            <script>
                jQuery(document).ready(function () {
                var html = \"<p class='error'>".$strErreurEmailExistant."</p>\";
                jQuery(html).insertBefore('#user_email');
                });
            </script>
            ";
        }
    }

    if ($_POST && $_POST['error']) {
        $errors->add('afpass_error', $_POST['error']);
    }
	
	if ($_POST && !$_POST["g-recaptcha-response"]) {
		$errors->add('captcha_no_valide', "<strong>ERROR</strong>: Captcha non valide");
	} elseif ($_POST) {
		$secret = get_site_option('af_gc_privatekey');
		if ($secret && !empty($secret)) {
			$reCaptcha = new ReCaptcha($secret);
			$resp = $reCaptcha->verifyResponse(
				$_SERVER["REMOTE_ADDR"],
				$_POST["g-recaptcha-response"]
			);
			if ($resp != null && $resp->success) {

			} else {
				$errors->add('captcha_no_valide', "<strong>ERROR</strong>: Captcha non valide");
			}
		}
	}
    ?>

    <p id="aferror" class="error" style="display: none;">
        <?php
        if ($errmsg = $errors->get_error_message('afpass_error')) {
            ?>
            <?php echo $errors->get_error_message('afpass_error'); ?>
        <?php } ?>
    </p>

	<input type="hidden" name="from" value="<?php echo $from; ?>" />
	<div class="col-2">
		<div class="col">
			<input id="prenom" class="input" type="text" tabindex="30" size="25" value="<?php echo $_POST['prenom']; ?>" name="prenom" placeholder="<?php echo __('First name','afnorpass');?>"/>
			<?php
			if ($errmsg = $errors->get_error_message('prenom_empty')) {
			?>
				<p class="error"><?php echo $errors->get_error_message('prenom_empty'); ?></p>
			<?php
			}
			?>
		</div>

		<div class="col">
			<input id="nom" class="input" type="text" tabindex="30" size="25" value="<?php echo $_POST['nom']; ?>" name="nom" placeholder="<?php echo __('Last name','afnorpass');?>"/>
			<?php
			if ($errmsg = $errors->get_error_message('nom_empty')) {
			?>
				<p class="error"><?php echo $errors->get_error_message('nom_empty'); ?></p>
			<?php } ?>
		</div>
	</div>
	
    <div class="input-group">
		<input id="password" class="input" type="password" tabindex="30" size="25" value="" name="password" placeholder="<?php echo $langue == "fr_FR" ? 'Mot de passe' : 'Password'; ?> "/>
		<p class="input-text">Le mot de passe doit contenir plus de 8 caractères, être composé d'au moins une minuscule, une majuscule, un chiffre et un caractère spécial.
Il ne doit pas contenir votre nom, prénom et des éléments de votre adresse email.</p>
    </div>
    <p>
		<input id="repeat_password" class="input" type="password" tabindex="40" size="25" value="" name="repeat_password" placeholder="<?php echo __('Password confirmation','afnorpass');?>"/>
    </p>
	<?php
    if ($errmsg = $errors->get_error_message('passwords_not_matched')) {
        ?><p class="error"><?php echo $errmsg; ?></p><?php
    } elseif ($errmsg = $errors->get_error_message('password_too_short')) {
        ?><p class="error"><?php echo $errmsg; ?></p><?php
    }
    ?>

    <?php
    if ($errmsg = $errors->get_error_message('captcha_no_valide')) {
        ?><p class="error"><?php echo $errmsg; ?></p><?php
    } elseif ($errmsg = $errors->get_error_message('captcha_no_valide')) {
        ?><p class="error"><?php echo $errmsg; ?></p><?php
    }
    ?>
	
    <?php
	if($langue == "fr_FR"){
		//francais
		$rgpd_1 = get_option("rgpd-1-fr");
		$rgpd_2 = get_option("rgpd-2-fr");
		$rgpd_3 = get_option("rgpd-3-fr");
		$langue = 'fr';
	 }else{
		//anglais
		$rgpd_1 = get_option("rgpd-1-en");
		$rgpd_2 = get_option("rgpd-2-en");
		$rgpd_3 = get_option("rgpd-3-en");
		$langue = 'en';
	 }
	$consentement = AfnorSSO::GetEntiteConsentement(get_site_option('af_ws_url'), '', 'AFNOR', $langue);

	//if (isset($consentement->PhraseConsentement)) {
    ?>
		<p class="checkbox-group agreements" style="margin:20px 0;color:#fff;">
			<input type="checkbox" id="rgpd_1" name="rgpd_1" value="1" <?php echo isset($_POST['rgpd_1']) && $_POST['rgpd_1'] === '1' ? 'checked="checked"' : '' ?>/>
			<label for="rgpd_1"><?php echo str_replace('&nbsp;', '<br class="force">', $rgpd_1);?></label>
		</p>
	<?php //} ?>
	<?php //if (isset($consentement->PhraseConsentementAutres)) { ?>
	<p class="checkbox-group agreements" style="margin:20px 0;color:#fff;">
		<input type="checkbox" id="rgpd_2" name="rgpd_2" value="1" <?php echo isset($_POST['rgpd_2']) && $_POST['rgpd_2'] === '1' ? 'checked="checked"' : '' ?>/>
		<label for="rgpd_2"><?php echo str_replace('&nbsp;', '<br class="force">', $rgpd_2);?></label>
    </p>
	<?php //} ?>
	
	<p class="checkbox-group agreements bordered" style="margin:20px 0;color:#fff;">
		<input type="checkbox" id="rgpd_3" name="rgpd_3" value="1" <?php echo isset($_POST['rgpd_3']) && $_POST['rgpd_3'] === '1' ? 'checked="checked"' : '' ?>/>
		<label for="rgpd_3"><?php echo str_replace('&nbsp;', '<br class="force">', $rgpd_3);?></label>
    </p>
    <?php
	if ($errmsg = $errors->get_error_message('rgpd_3_empty')) {
	?>
		<p class="error"><?php echo $errors->get_error_message('rgpd_3_empty'); ?></p>
	<?php } ?>

 
    <?php
    //$page_login = get_site_option('page_login');
    $af_gc_sitekey = get_site_option('af_gc_sitekey');
    if ($af_gc_sitekey && !empty($af_gc_sitekey)) {
		?>
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<div id='recaptcha' class="g-recaptcha"
				 data-sitekey="<?php echo $af_gc_sitekey ?>"
				 data-callback="onSubmit"
				 data-size="invisible"></div>
		<script>
			function onSubmit() {
				document.getElementById("setupform").submit();
			}
			jQuery(document).ready(function(){
				label = jQuery('#setupform input.submit').val();
				jQuery('#setupform input.submit').replaceWith('<button class="submit">' + label + '</button>');
				jQuery('#setupform').submit(function(event){
					if(jQuery('#rgpd_3').prop('checked') != true) {
						jQuery('#rgpd_3_error').remove();
						jQuery('#rgpd_3').parent().append('<p class="error" id="rgpd_3_error"><?php echo addslashes (__('<strong>ERROR</strong>: You must accept the terms of use.','afnorpass')) ?></p>');
						jQuery('#rgpd_3_error').focus();
						event.preventDefault();
						return false;
					}
					
					if (!grecaptcha.getResponse()) {
						event.preventDefault(); //prevent form submit
						grecaptcha.execute();
					} else {
						console.log('form really submitted.');
					}
				});
			});
		</script>
		<?php
	}
	?>
    <script>
	jQuery(document).ready(function(){
		jQuery('form#setupform input.submit').val('<?php echo $langue == "fr_FR" ? "Continuer" : "Next"; ?>');
		if (jQuery('#aferror').html() != '') {
			jQuery('p.error:first').html(jQuery('#aferror').html());
		}
		
		if (jQuery('p.error:first').html()) {
			jQuery('p.error:first').remove();
		}
		jQuery('body').on('click', '.submit', function () {
			jQuery('#user_name').val(jQuery('#user_email').val());
		});
		jQuery('#user_name').hide();
		jQuery('form#setupform label:first').hide();
		jQuery('form#setupform br:not(.force)').hide();
		
		var chn = jQuery('label[for=user_email]').text();
		var nouvChn = chn.replace(/:/i, '*');
		jQuery('label[for=user_email]').remove();
		jQuery('#user_email').attr('placeholder', nouvChn);
		
		jQuery('<div/>', {
			id: 'user_email_container',
			class: 'input-group',
		}).insertAfter('#user_email');
		jQuery('#user_email').detach().appendTo('#user_email_container');
		jQuery('#user_email_container').append('<p class="input-text"><?php echo _e( "We send your registration email to this address. (Double-check your email address before continuing.)" ) ?></p>');
		
		jQuery('form#setupform').show();
	});
    </script>



    <?php
}

add_action('wp_footer', 'remove_admin_bar');
function remove_admin_bar()
{
    echo "<style>html{margin-top:0 !important;}</style><script>
    jQuery(document).ready( function() {
    jQuery(\"#wpadminbar\").remove();
    });
    </script>
      ";
}



/**
 * Redirect user after successful login.
 *
 * @param string $redirect_to URL to redirect to.
 * @param string $request URL the user is coming from.
 * @param object $user Logged user's data.
 * @return string
 */
function my_login_redirect( $redirect_to, $request, $user ) {
        return $redirect_to;

}

add_filter( 'login_redirect', 'my_login_redirect', 10, 3 );


/**
 * Plugin Name: User Access Manager
 * Plugin URI: http://www.gm-alex.de/projects/wordpress/plugins/user-access-manager/
 * Author URI: http://www.gm-alex.de/
 * Version: 1.2.6.10
 * Author: Alexander Schneider
 * Description: Manage the access to your posts, pages, categories and files.
 *
 * user-access-manager.php
 *
 * PHP versions 5
 *
 * @category  UserAccessManager
 * @package   UserAccessManager
 * @author    Alexander Schneider <alexanderschneider85@gmail.com>
 * @copyright 2008-2013 Alexander Schneider
 * @license   http://www.gnu.org/licenses/gpl-2.0.html  GNU General Public License, version 2
 * @version   SVN: $Id$
 * @link      http://wordpress.org/extend/plugins/user-access-manager/
 */

//Paths
load_plugin_textdomain('user-access-manager', false, 'user-access-manager/lang');
define('UAM_URLPATH', plugins_url('', __FILE__).'/');

if (defined('UAM_LOCAL_DEBUG')) {
    define('UAM_REALPATH', plugin_basename(dirname(__FILE__)).'/'); //ONLY FOR MY LOCAL DEBUG
} else {
    define('UAM_REALPATH', WP_PLUGIN_DIR.'/'.plugin_basename(dirname(__FILE__)).'/');
}


//Defines
require_once 'includes/database.define.php';
require_once 'includes/language.define.php';


//Check requirements
$blStop = false;

//Check php version
$sPhpVersion = phpversion();

if (version_compare($sPhpVersion, "5.0") === -1) {
    add_action(
        'admin_notices',
        create_function(
            '',
            'echo \'<div id="message" class="error"><p><strong>'.
            sprintf(TXT_UAM_PHP_VERSION_TO_LOW, $sPhpVersion).
            '</strong></p></div>\';'
        )
    );

    $blStop = true;
}

//Check wordpress version
global $wp_version;

if (version_compare($wp_version, "3.0") === -1) {
    add_action(
        'admin_notices',
        create_function(
            '',
            'echo \'<div id="message" class="error"><p><strong>'.
            sprintf(TXT_UAM_WORDPRESS_VERSION_TO_LOW, $wp_version).
            '</strong></p></div>\';'
        )
    );

    $blStop = true;
}

//If we have a error stop plugin.
if ($blStop) {
    return;
}

if (class_exists("UserAccessManager")) {
    $oUserAccessManager = new UserAccessManager();
}

//Initialize the admin panel
if (!function_exists("userAccessManagerAP")) {
    /**
     * Creates the filters and actions for the admin panel
     *
     * @return null;
     */
    function userAccessManagerAP()
    {
        global $oUserAccessManager;
        $oCurrentUser = $oUserAccessManager->getCurrentUser();

        if (!isset($oUserAccessManager)) {
            return;
        }

        $oUserAccessManager->setAtAdminPanel();
        $aUamOptions = $oUserAccessManager->getAdminOptions();

        if ($oUserAccessManager->isDatabaseUpdateNecessary()) {
            $sLink = 'admin.php?page=uam_setup';

            add_action(
                'admin_notices',
                create_function(
                    '',
                    'echo \'<div id="message" class="error"><p><strong>'.
                    sprintf(TXT_UAM_NEED_DATABASE_UPDATE, $sLink).
                    '</strong></p></div>\';'
                )
            );
        }

        get_currentuserinfo();
        $oCurUserData = wp_get_current_user();
        $oUamAccessHandler = $oUserAccessManager->getAccessHandler();
        $aTaxonomies = get_taxonomies(array('public' => true, '_builtin' => false));

        if ($oUamAccessHandler->checkUserAccess()
            || $aUamOptions['authors_can_add_posts_to_groups'] == 'true'
        ) {
            //Admin actions
            if (function_exists('add_action')) {
                add_action('admin_print_styles', array($oUserAccessManager, 'addStyles'));
                add_action('wp_print_scripts', array($oUserAccessManager, 'addScripts'));

                add_action('manage_posts_custom_column', array($oUserAccessManager, 'addPostColumn'), 10, 2);
                add_action('manage_pages_custom_column', array($oUserAccessManager, 'addPostColumn'), 10, 2);
                add_action('save_post', array($oUserAccessManager, 'savePostData'));

                add_action('manage_media_custom_column', array($oUserAccessManager, 'addPostColumn'), 10, 2);

                //Actions are only called when the attachment content is modified so we can't use it.
                //add_action('add_attachment', array($oUserAccessManager, 'savePostData'));
                //add_action('edit_attachment', array($oUserAccessManager, 'savePostData'));

                add_action('edit_user_profile', array($oUserAccessManager, 'showUserProfile'));
                add_action('profile_update', array($oUserAccessManager, 'saveUserData'));

                add_action('edit_category_form', array($oUserAccessManager, 'showCategoryEditForm'));
                add_action('create_category', array($oUserAccessManager, 'saveCategoryData'));
                add_action('edit_category', array($oUserAccessManager, 'saveCategoryData'));

                add_action('bulk_edit_custom_box', array($oUserAccessManager, 'addBulkAction'));


                //Taxonomies
                foreach ($aTaxonomies as $sTaxonomy) {
                    add_filter('manage_edit-'.$sTaxonomy.'_columns', array($oUserAccessManager, 'addCategoryColumnsHeader'));
                    add_action('manage_'.$sTaxonomy.'_custom_column', array($oUserAccessManager, 'addCategoryColumn'), 10, 3);
                    add_action($sTaxonomy.'_add_form_fields', array($oUserAccessManager, 'showCategoryEditForm'));
                    add_action('create_'.$sTaxonomy, array($oUserAccessManager, 'saveCategoryData'));
                    add_action('edit_'.$sTaxonomy, array($oUserAccessManager, 'saveCategoryData'));
                }
            }

            //Admin filters
            if (function_exists('add_filter')) {
                //The filter we use instead of add|edit_attachment action, reason see top
                add_filter('attachment_fields_to_save', array($oUserAccessManager, 'saveAttachmentData'));

                add_filter('manage_posts_columns', array($oUserAccessManager, 'addPostColumnsHeader'));
                add_filter('manage_pages_columns', array($oUserAccessManager, 'addPostColumnsHeader'));

                add_filter('manage_users_columns', array($oUserAccessManager, 'addUserColumnsHeader'), 10);
                add_filter('manage_users_custom_column', array($oUserAccessManager, 'addUserColumn'), 10, 3);

                add_filter('manage_edit-category_columns', array($oUserAccessManager, 'addCategoryColumnsHeader'));
                add_filter('manage_category_custom_column', array($oUserAccessManager, 'addCategoryColumn'), 10, 3);
            }

            if ($aUamOptions['lock_file'] == 'true') {
                add_action('media_meta', array($oUserAccessManager, 'showMediaFile'), 10, 2);
                add_filter('manage_media_columns', array($oUserAccessManager, 'addPostColumnsHeader'));
            }
        }

        //Clean up at deleting should always be done.
        if (function_exists('add_action')) {
            add_action('update_option_permalink_structure', array($oUserAccessManager, 'updatePermalink'));
            add_action('wp_dashboard_setup', array($oUserAccessManager, 'setupAdminDashboard'));
            add_action('delete_post', array($oUserAccessManager, 'removePostData'));
            add_action('delete_attachment', array($oUserAccessManager, 'removePostData'));
            add_action('delete_user', array($oUserAccessManager, 'removeUserData'));
            add_action('delete_category', array($oUserAccessManager, 'removeCategoryData'), 10, 2);

            // taxonomies

            foreach ($aTaxonomies as $sTaxonomy) {
                add_action('delete_'.$sTaxonomy, array($oUserAccessManager, 'removeCategoryData'));
            }
        }

        $oUserAccessManager->noRightsToEditContent();
    }
}

if (!function_exists("userAccessManagerAPMenu")) {
    /**
     * Creates the menu at the admin panel
     *
     * @return null;
     */
    function userAccessManagerAPMenu()
    {
        global $oUserAccessManager;
        $oCurrentUser = $oUserAccessManager->getCurrentUser();

        if (!isset($oUserAccessManager)) {
            return;
        }

        $aUamOptions = $oUserAccessManager->getAdminOptions();

        if (ini_get('safe_mode')
            && $aUamOptions['download_type'] == 'fopen'
        ) {
            add_action(
                'admin_notices',
                create_function(
                    '',
                    'echo \'<div id="message" class="error"><p><strong>'.
                    TXT_UAM_FOPEN_WITHOUT_SAVEMODE_OFF.
                    '</strong></p></div>\';'
                )
            );
        }

        $oCurUserData = get_userdata($oCurrentUser->ID);
        $oUamAccessHandler = $oUserAccessManager->getAccessHandler();

        if ($oUamAccessHandler->checkUserAccess()) {
            //TODO
            /**
             * --- BOF ---
             * Not the best way to handle full user access capabilities seems
             * to be the right way, but it is way difficult.
             */

            //Admin main menu
            if (function_exists('add_menu_page')) {
                add_menu_page('User Access Manager', 'UAM', 'manage_options', 'uam_usergroup', array($oUserAccessManager, 'printAdminPage'), 'div');
            }

            //Admin sub menus
            if (function_exists('add_submenu_page')) {
                add_submenu_page('uam_usergroup', TXT_UAM_MANAGE_GROUP, TXT_UAM_MANAGE_GROUP, 'read', 'uam_usergroup', array($oUserAccessManager, 'printAdminPage'));
                add_submenu_page('uam_usergroup', TXT_UAM_SETTINGS, TXT_UAM_SETTINGS, 'read', 'uam_settings', array($oUserAccessManager, 'printAdminPage'));
                add_submenu_page('uam_usergroup', TXT_UAM_SETUP, TXT_UAM_SETUP, 'read', 'uam_setup', array($oUserAccessManager, 'printAdminPage'));
                add_submenu_page('uam_usergroup', TXT_UAM_ABOUT, TXT_UAM_ABOUT, 'read', 'uam_about', array($oUserAccessManager, 'printAdminPage'));

                do_action('uam_add_submenu');
            }
            /**
             * --- EOF ---
             */
        }

        if ($oUamAccessHandler->checkUserAccess()
            || $aUamOptions['authors_can_add_posts_to_groups'] == 'true'
        ) {
            //Admin meta boxes
            if (function_exists('add_meta_box')) {
                $aPostableTypes = $oUamAccessHandler->getPostableTypes();

                foreach ($aPostableTypes as $sPostableType) {
                    add_meta_box('uma_post_access', 'Access', array($oUserAccessManager, 'editPostContent'), $sPostableType, 'side');
                }

                /*add_meta_box('uma_post_access', 'Access', array($oUserAccessManager, 'editPostContent'), 'post', 'side');
                add_meta_box('uma_post_access', 'Access', array($oUserAccessManager, 'editPostContent'), 'page', 'side');*/
            }
        }
    }
}

if (!function_exists("userAccessManagerUninstall")) {
    function userAccessManagerUninstall() {
        $oUserAccessManager = new UserAccessManager();
        $oUserAccessManager->uninstall();
    }
}

if (isset($oUserAccessManager)) {
    //install
    if (function_exists('register_activation_hook')) {
        register_activation_hook(__FILE__, array($oUserAccessManager, 'install'));
    }

    //uninstall
    if (function_exists('register_uninstall_hook')) {
        register_uninstall_hook(__FILE__, 'userAccessManagerUninstall');
    } elseif (function_exists('register_deactivation_hook')) {
        //Fallback
        register_deactivation_hook(__FILE__, array($oUserAccessManager, 'uninstall'));
    }

    //deactivation
    if (function_exists('register_deactivation_hook')) {
        register_deactivation_hook(__FILE__, array($oUserAccessManager, 'deactivate'));
    }

    //Redirect
    $aUamOptions = $oUserAccessManager->getAdminOptions();

    if ($aUamOptions['redirect'] != 'false' || isset($_GET['uamgetfile'])) {
        add_filter('wp_headers', array($oUserAccessManager, 'redirect'), 10, 2);
    }

    //Actions
    if (function_exists('add_action')) {
        add_action('wp_print_scripts', array($oUserAccessManager, 'addScripts'));
        add_action('wp_print_styles', array($oUserAccessManager, 'addStyles'));
        add_action('admin_init', 'userAccessManagerAP');
        add_action('admin_menu', 'userAccessManagerAPMenu');
    }

    //Filters
    if (function_exists('add_filter') && get_site_option('page_login')) {
        add_filter('wp_get_attachment_thumb_url', array($oUserAccessManager, 'getFileUrl'), 10, 2);
        add_filter('wp_get_attachment_url', array($oUserAccessManager, 'getFileUrl'), 10, 2);
        add_filter('the_posts', array($oUserAccessManager, 'showPost'));
        add_filter('posts_where_paged', array($oUserAccessManager, 'showPostSql'));
        add_filter('wp_get_nav_menu_items', array($oUserAccessManager, 'showCustomMenu'));
        add_filter('comments_array', array($oUserAccessManager, 'showComment'));
        add_filter('the_comments', array($oUserAccessManager, 'showComment'));
        add_filter('get_pages', array($oUserAccessManager, 'showPage'));
        add_filter('get_terms', array($oUserAccessManager, 'showTerms'), 10, 2);
        add_filter('get_next_post_where', array($oUserAccessManager, 'showNextPreviousPost'));
        add_filter('get_previous_post_where', array($oUserAccessManager, 'showNextPreviousPost'));
        add_filter('post_link', array($oUserAccessManager, 'cachePostLinks'), 10, 2);
        add_filter('edit_post_link', array($oUserAccessManager, 'showGroupMembership'), 10, 2);
        add_filter('parse_query', array($oUserAccessManager, 'parseQuery'));
        add_filter('getarchives_where', array($oUserAccessManager, 'showPostSql'));
        add_filter('wpseo_sitemap_entry', array($oUserAccessManager, 'wp_seo_url'), 1, 3);
    }
}

//Add the cli interface to the known commands
if (defined('WP_CLI') && WP_CLI) {
    include __DIR__.'/includes/wp-cli.php';
}